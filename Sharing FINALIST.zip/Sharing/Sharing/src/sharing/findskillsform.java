/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package sharing;

/**
 *
 * @author NINGMEI®
 */

import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;

public class findskillsform extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(findskillsform.class.getName());

    /**
     * Creates new form findskillsform
     */
    
    private user loggedinuser;
    
    public findskillsform(user loggedinuser) {
        initComponents();
        ScreenUtil.fullScreenCentered(this);
        
        this.loggedinuser = loggedinuser;
        showskills.setDefaultEditor(Object.class,null);
        populateSkillCombo();
        skillCombo.addActionListener(this::skillComboActionPerformed);
  
    }
    
    private void populateSkillCombo() {
        skillCombo.removeAllItems();
        skillCombo.addItem("Select Skills");
        skillCombo.addItem("All Skills");
        
        String sql = "SELECT DISTINCT SkillName FROM Skills ORDER BY SkillName";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                skillCombo.addItem(rs.getString("SkillName"));
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading skills: " + e.getMessage());
        }
    }

    private void searchSkills () {
        String searches = search.getText().trim();
    
        if (searches.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter a skill");
            return;
        }
    
        String[] skillsToSearch = searches.split(",");
        boolean found = displayStudents(skillsToSearch);
    
        if (!found) {
            JOptionPane.showMessageDialog(this, "No students found with those skills");
        }
    }

    private boolean displayStudents(String[] skillsFilter) {
        DefaultTableModel model = (DefaultTableModel) showskills.getModel();
        model.setRowCount(0);
        boolean found = false;

        String ratingSub =
            "(SELECT ROUND(AVG(f.Rating), 1) FROM Feedback f " +
            "JOIN Request r ON f.RequestID = r.RequestID " +
            "WHERE r.HelperID = s.StudentID) AS AvgRating";

        StringBuilder sql = new StringBuilder();

        if (skillsFilter == null) {
            sql.append(
                    "SELECT CONCAT(s.First_Name, ' ', s.Last_Name) AS FullName, " +
                    "GROUP_CONCAT(sk.SkillName ORDER BY sk.SkillName SEPARATOR ', ') AS SkillName, " +
                    "s.StudentID, s.SchoolYear, " + ratingSub + " " +
                    "FROM Student s " +
                    "JOIN UserSkill us ON s.StudentID = us.StudentID " +
                    "JOIN Skills sk ON us.SkillID = sk.SkillID " +
                    "WHERE s.StudentID != ? " +
                    "GROUP BY s.StudentID, s.First_Name, s.Last_Name, s.SchoolYear " +
                    "ORDER BY s.SchoolYear ASC, FullName ASC"
                );
            } else {
     
                sql.append(
                    "SELECT CONCAT(s.First_Name, ' ', s.Last_Name) AS FullName, sk.SkillName, " +
                    "s.StudentID, s.SchoolYear, " + ratingSub + " " +
                    "FROM Student s " +
                    "JOIN UserSkill us ON s.StudentID = us.StudentID " +
                    "JOIN Skills sk ON us.SkillID = sk.SkillID " +
                    "WHERE s.StudentID != ?"
                );

                sql.append(" AND (");
                for (int i = 0; i < skillsFilter.length; i++) {
                    if (i > 0) sql.append(" OR ");
                    sql.append("sk.SkillName = ?");
                }
                sql.append(")");

                sql.append(" ORDER BY s.SchoolYear ASC, FullName ASC, sk.SkillName ASC");
            }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            stmt.setString(1, loggedinuser.getStudentId());

            if (skillsFilter != null) {
                for (int i = 0; i < skillsFilter.length; i++) {
                    stmt.setString(i + 2, skillsFilter[i].trim());
                }
            }

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                double avg = rs.getDouble("AvgRating");
                String ratingText = rs.wasNull() ? "No ratings yet" : avg + " / 5";
                model.addRow(new Object[]{
                    rs.getString("FullName"),
                    rs.getString("SkillName"),
                    rs.getString("StudentID"),
                    rs.getString("SchoolYear"),
                    ratingText
                });
                found = true;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error searching skills: " + e.getMessage());
        }

        return found;
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBox1 = new javax.swing.JCheckBox();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        search = new javax.swing.JTextField();
        btnsearch = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        showskills = new javax.swing.JTable();
        skillback = new javax.swing.JButton();
        req = new javax.swing.JButton();
        skillCombo = new javax.swing.JComboBox<>();
        jPanel5 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();

        jCheckBox1.setText("jCheckBox1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(134, 163, 182));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        jLabel2.setText("Find skills:");
        jLabel2.setBorder(new javax.swing.border.MatteBorder(null));

        search.addActionListener(this::searchActionPerformed);

        btnsearch.setBackground(new java.awt.Color(255, 255, 204));
        btnsearch.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        btnsearch.setText("SEARCH");
        btnsearch.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnsearch.addActionListener(this::btnsearchActionPerformed);

        jLabel3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        jLabel3.setText("Results:");
        jLabel3.setBorder(new javax.swing.border.MatteBorder(null));

        showskills.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Student", "Skills", "Student ID", "Year", "Rating"
            }
        ));
        jScrollPane1.setViewportView(showskills);

        skillback.setBackground(new java.awt.Color(204, 204, 204));
        skillback.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        skillback.setText("BACK");
        skillback.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        skillback.addActionListener(this::skillbackActionPerformed);

        req.setBackground(new java.awt.Color(153, 255, 153));
        req.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        req.setText("REQUEST HELP");
        req.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        req.addActionListener(this::reqActionPerformed);

        skillCombo.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        skillCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Skills", "Java", "Python", "C++", "HTML", "CSS", " ", " " }));
        skillCombo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        skillCombo.addActionListener(this::skillComboActionPerformed);

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));

        jLabel4.setBackground(new java.awt.Color(204, 204, 255));
        jLabel4.setFont(jLabel4.getFont().deriveFont(jLabel4.getFont().getStyle() | java.awt.Font.BOLD, jLabel4.getFont().getSize()+24));
        jLabel4.setText("SEARCH SKILLS");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(skillback, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnsearch, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(skillCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 773, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addComponent(req, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(315, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2))
                    .addComponent(skillCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnsearch, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                        .addComponent(skillback, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(155, 155, 155))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(req, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
        searchSkills();
    }//GEN-LAST:event_btnsearchActionPerformed

    private void skillbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_skillbackActionPerformed
        dashboardform dashboard = new dashboardform(loggedinuser);
        dashboard.setVisible(true);

         this.setVisible(false);
    }//GEN-LAST:event_skillbackActionPerformed

    private void reqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reqActionPerformed
        int selectedRow = showskills.getSelectedRow();
        
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Select a student first");
            return;
        }
        
        String helperId = showskills.getValueAt(selectedRow, 2).toString();
        String skillName = showskills.getValueAt(selectedRow, 1).toString();

        if (skillName.contains(",")) {
            String[] options = skillName.split(",\\s*");
            String chosen = (String) JOptionPane.showInputDialog(this,"Which skill do you need help with?","Choose Skill",JOptionPane.PLAIN_MESSAGE,null,options,options[0]);

            if (chosen == null) {
                return; 
            }
            skillName = chosen;
        }
        
        String getSkillIdSql = "SELECT SkillID FROM Skills WHERE SkillName = ?";
        String insertSql = "INSERT INTO Request (RequesterID, HelperID, SkillID, Status, DateRequested) " +"VALUES (?, ?, ?, 'Pending', CURDATE())";
        
        try (Connection conn = DBConnection.getConnection()) {
            
            int skillId;
            try (PreparedStatement skillStmt = conn.prepareStatement(getSkillIdSql)) {
                skillStmt.setString(1, skillName);
                ResultSet rs = skillStmt.executeQuery();
                if (!rs.next()) {
                    JOptionPane.showMessageDialog(this, "Skill not found.");
                    return;
                }
                skillId = rs.getInt("SkillID");
            }
             String dupSql = "SELECT 1 FROM Request WHERE RequesterID = ? AND HelperID = ? AND SkillID = ? AND Status IN ('Pending', 'Accepted')";
                try (PreparedStatement dupStmt = conn.prepareStatement(dupSql)) {
                dupStmt.setString(1, loggedinuser.getStudentId());
                dupStmt.setString(2, helperId);
                dupStmt.setInt(3, skillId);
                if (dupStmt.executeQuery().next()) {
                    JOptionPane.showMessageDialog(this, "You already have an active request for that skill with this student.");
                    return;
                }
            }   

            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                insertStmt.setString(1, loggedinuser.getStudentId());
                insertStmt.setString(2, helperId);
                insertStmt.setInt(3, skillId);
                insertStmt.executeUpdate();
            }
            
            JOptionPane.showMessageDialog(this, "Request sent!");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error sending request: " + e.getMessage());
        }
    }//GEN-LAST:event_reqActionPerformed

    private void skillComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_skillComboActionPerformed
        String selected = (String) skillCombo.getSelectedItem();
        
        if (selected == null || selected.equals("Select Skills")) {
            return; 
        }
        if (selected.equals("All Skills")) {
            displayStudents(null);
        } else {
            displayStudents(new String[]{ selected });
        }
    }//GEN-LAST:event_skillComboActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnsearch;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton req;
    private javax.swing.JTextField search;
    private javax.swing.JTable showskills;
    private javax.swing.JComboBox<String> skillCombo;
    private javax.swing.JButton skillback;
    // End of variables declaration//GEN-END:variables
}
