/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sharing;

/**
 *
 * @author User
 */

import java.util.ArrayList;
public class user {
    private String studentid;
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String schoolYear;
    
    private ArrayList<String> skills = new ArrayList<>();
    
    public user(String studentid, String firstName, String lastName, String username, String password, String schoolYear) {
        this.studentid = studentid;
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.schoolYear = schoolYear;
    }
    
    public String getStudentId () {
        return studentid;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public String getName () {
        return firstName + " " + lastName;
    }
    
    public String getUsername () {
        return username;
    }
    
    public String getPassword () {
        return password;
    }
    
    public ArrayList<String> getSkills() {
        return skills;
    }
    
    public void addSkill (String skill) {
        skills.add(skill);
    }
    
    public void removeSkill(String skill) {
        skills.remove(skill);
    }
    
    public String getSchoolYear() {
        return schoolYear;
    }
    public void setStudentId(String studentid) {
    this.studentid = studentid;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setSchoolYear(String schoolYear) {
        this.schoolYear = schoolYear;
    }
 } 
