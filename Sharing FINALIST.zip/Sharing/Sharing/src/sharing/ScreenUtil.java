/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sharing;

/**
 *
 * @author NINGMEI®
 */
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Rectangle;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
public class ScreenUtil {
     public static void fullScreenCentered(JFrame frame) {
        java.awt.Container content = frame.getContentPane();

        JPanel wrapper = new JPanel(new java.awt.GridBagLayout());
        wrapper.setBackground(content.getBackground());
        wrapper.add(content);

        frame.setContentPane(wrapper);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    public static JPanel centered(JComponent panel) {
        JPanel wrapper = new JPanel(null) {
            private boolean busy = false;

            @Override
            public void doLayout() {
                if (busy) return;
                busy = true;
                try {
                    Dimension pref = panel.getPreferredSize();
                    panel.setBounds(0, 0, pref.width, pref.height);
                    panel.validate();

                    Rectangle b = contentBounds(panel, panel);
                    if (b == null) {
                        b = new Rectangle(0, 0, pref.width, pref.height);
                    }

                    int x = (getWidth() - b.width) / 2 - b.x;
                    int y = (getHeight() - b.height) / 2 - b.y;
                    panel.setLocation(x, y);
                } finally {
                    busy = false;
                }
            }
        };
        wrapper.setBackground(panel.getBackground());
        wrapper.add(panel);
        return wrapper;
    }

    private static Rectangle contentBounds(Container root, Component c) {
        if (!c.isVisible()) return null;

        if (c instanceof Container && ((Container) c).getComponentCount() > 0) {
            Rectangle result = null;
            for (Component child : ((Container) c).getComponents()) {
                Rectangle r = contentBounds(root, child);
                if (r != null) {
                    result = (result == null) ? r : result.union(r);
                }
            }
            return result;
        }

        if (c == root) return null;
        return SwingUtilities.convertRectangle(c.getParent(), c.getBounds(), root);
    }
    
}
